---
layout: single
title: "Contact"
permalink: /contact/
author_profile: true
---

📧 Email: your.email@example.com  
🔗 [LinkedIn](https://linkedin.com/in/yourprofile)  
💻 [GitHub](https://github.com/v-nagamanohar)
