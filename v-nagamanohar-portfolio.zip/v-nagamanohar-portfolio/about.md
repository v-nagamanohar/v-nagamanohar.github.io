---
layout: single
title: "About Me"
permalink: /about/
author_profile: true
---

Hi, I'm **Nagamanohar**, a passionate data analyst with experience in Excel, SQL, Power BI, and Python.
I love turning raw data into clear, actionable insights.

This portfolio showcases some of my key projects and case studies.
